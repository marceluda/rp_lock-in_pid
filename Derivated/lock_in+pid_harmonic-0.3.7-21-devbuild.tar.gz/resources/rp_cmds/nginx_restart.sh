#!/bin/bash

systemctl stop redpitaya_nginx && systemctl start redpitaya_nginx
