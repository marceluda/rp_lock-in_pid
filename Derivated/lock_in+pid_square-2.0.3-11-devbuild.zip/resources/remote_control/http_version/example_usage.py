#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Example usage of remote control by control Finn

Each "#%%" block is a cell (Spyder / VS Code / IPython): run them one by one.
Tested with the App v2.3.15 on Ecosystem 2.0 (RedPitaya_OS 2.04); scope_stop()/scope_auto(): v2.3.16.
lock_in+pid_square v2.0.0 (Square Lock-in+PID): square generator and lock-in (sq_ref / sq_quad / sq_phas,
sqX / sqY / sqF) instead of the harmonic ones of lock_in+pid_harmonic.
"""

import os
import json

from time import sleep

from control_finn import RedPitayaApp, reg_labels


#%%  Connect to RP

# URL of the App (as copied from the browser; '?type=run' is removed)
URL = os.environ.get('RP_URL', 'http://rp-XXXXXX.local/lock_in+pid_square/?type=run')

rp =  RedPitayaApp(URL)

print(rp)
print('Calibration constants read:', len(rp.calib))



#%% Example configuration and acquisition #####################################

"""
The C controller of the App (the scope of the web page) keeps acquiring in Auto after the App is
started, even with no web page open, and uses the same scope. osc.measure() / acquire() stop it first
(trig_mode = 2, as a Single acquisition of the page): rp.scope_stop(). Give the scope back to the page
with rp.scope_auto() (see the cell "Give the scope back to the web page" below).
If it can not be confirmed stopped (no answer of POST /data), acquire() raises
control_finn.WebScopeNotStopped and does not acquire: try again, or press Single in the web page.
"""

print('scope of the web page, trig_mode (0 Auto, 1 Normal, 2 Single):', rp.scope_mode())

rp.lock.oscA_sw = 'sq_ref'
rp.lock.oscB_sw = 'sq_quad'

rp.lock.gen_mod_sqp = 322499    # f = 125 MHz / (2*(322499+1)) = 193.8 Hz

# trigger on the rising edge of channel A (sq_ref) at 0, 20 samples before the trigger
rp.osc.measure('A_rising', dec=256 , trig_pos=20 , threshold=0, wait=True)

rp.wait_osc_finish()   # (already finished: wait=True above)

tt, ch1, ch2 = rp.osc.curv()

rp.plot_meas()




#%% get the data  #############################################################


rp.lock.oscA_sw = 'sq_ref'
rp.lock.oscB_sw = 'sq_quad'

rp.lock.gen_mod_sqp = 322499    # 193.8 Hz

# measure + wait + curv in one call. raw=False: Volts
tt, ch1, ch2 = rp.acquire('A_rising', dec=256 , trig_pos=20, raw=False)


from matplotlib import pyplot as plt

plt.figure()
plt.plot(tt,ch1,tt,ch2)


#%% Manual trigger and external (lock module) trigger  #########################

# manual: triggers at once, trigger in the middle of the trace
tt, ch1, ch2 = rp.acquire('manual', dec=64, trig_pos=0.5)

# external: the trigger made by the lock module (lock.trig_sw), e.g. the scan floor of the ramp
rp.lock.trig_sw = 'Scan floor'
tt, ch1, ch2 = rp.acquire('ext_rising', dec=1024, trig_pos=0.1, timeout=20)


#%% Give the scope back to the web page  ######################################

# The acquisitions above stopped the scope of the web page (C controller): restart it in Auto.
rp.scope_auto()
print('trig_mode:', rp.scope_mode())

# To acquire from Python while the web page keeps its scope running (not recommended: the data
# can be mixed), disable the automatic stop:
#   rp.osc.auto_stop_web_scope = False      or      rp.acquire(..., stop_web_scope=False)


#%% save data and load it later  ##############################################



rp.lock.oscA_sw = 'sq_ref'
rp.lock.oscB_sw = 'sq_quad'

rp.lock.gen_mod_sqp = 322499    # 193.8 Hz

rp.osc.measure('A_rising', dec=256 , trig_pos=20 , wait=True)

rp.wait_osc_finish()

tt, ch1, ch2 = rp.osc.curv()

fn = rp.save_last_meas()

print(f"You saved data in file: {fn}")

# measure() stopped the scope of the web page again (scope_stop()): give it back, otherwise the page stays
# in Single (its plot and the lock state shown do not refresh until Auto is pressed)
rp.scope_auto()



#%% Load saveda data
rp2 =  RedPitayaApp(fn)

# rp2._last_osc_dump is a dict with the saved data


rp2.plot_meas()


tt, ch1, ch2 = rp2.osc.curv('last')
plt.figure()
plt.plot(tt,ch1,tt,ch2)



#%% Lock-in: input, frequency, phase, filters, gains  #########################

rp.set_signal('in1')                 # lock-in input (signal_sw)
print('f =', rp.set_freq_hz(10e3), 'Hz')          # closest square frequency with sq_quad at 90 deg (gen_mod_sqp odd)
print('f =', rp.set_freq(1), 'Hz')                 # or with the register value: 1 -> 31.25 MHz (the maximum with quadrature)
print('f =', rp.set_freq(1249), 'Hz')              # 50 kHz
print('phase =', rp.set_phase(625), 'deg')         # sq_phas / sqF delay in ticks (period 2500 ticks: 90 deg)
print('phase =', rp.set_phase(90, units='deg'), 'deg')
rp.set_modulation_amplitud(-1, ch='out1')          # -1: no modulation added to OUT1

rp.set_lpf(tau_exponent=15, order=2, line='xy')    # sqX, sqY: tau = 8 ns * 2**15 = 262 us, 2nd order
rp.set_lpf(tau_exponent=18, order=1, line='all')   # sqX, sqY and sqF
print(rp.get_lpf())                                # dict name -> (tau [s], order)
print(rp.get_lpf('xy'))

rp.set_gain('xy', 'x32')             # sqXo, sqYo = sqX, sqY * 32
print('sqX, sqY [V] =', rp.get_XY())
print('sqX, sqY, sqF [int] =', rp.get_XY(units='int', F=True))


#%% PID  ######################################################################

rp.set_pid('A', sw='error', sp=0, kp=0, ki=0, kd=0, PSR='/1024', ISR='537 ms', DSR=0, SAT=13)
print(rp.get_pid('A'))
rp.pid_reset('A')                    # integrator reset

rp.lock.error_sw = 'sqYo'            # error signal = sqYo
rp.lock.out1_sw  = 'ctrl_A'          # OUT1 = PID A + ramp A


#%% Ramp (scan)  ##############################################################

# Same ramp as the lock_mode config (test_files/lock_in+pid_square__lock_mode.json): +-5000 counts with
# step=400 gives a triangle of ~64 ms (scan floor every ~64 ms), so the 16.58 ms time trigger of the Lock cell
# below falls inside the rising half. ramp_step is a divider of the period: a smaller step is a FASTER ramp
# (step=100, +-4000 gives ~12.9 ms, shorter than 16.58 ms: the time trigger would never fire).
rp.set_ramp(step=400, low=-5000, high=5000, sawtooth=False, enable=True)
rp.set_manual(ramp=True, pidA=False, pidB=False)   # "Scan enable": the ramp runs, PIDs off
print(rp.get_ramp())
print(rp.lock_status())


#%% Lock  #####################################################################

# The cells "Lock-in" and "PID" above are examples of each call: they turned the modulation off
# (set_modulation_amplitud(-1)), changed frequency, phase, filters and gain, and left PID A with kp = ki = 0.
# Without modulation there is no error signal (the level trigger never fires) and with kp = ki = 0 there is no
# feedback (the lock "closes", LOCKED, but holds nothing). Restore the lock-in and PID A of the lock_mode config
# (test_files/lock_in+pid_square__lock_mode.json, the one of the lock tests with dummy_simulator) first:
RESTORE_LOCK_MODE = True
if RESTORE_LOCK_MODE:
    rp.set_signal('in1')                               # lock-in input
    rp.set_freq(1249)                                  # gen_mod_sqp 1249: 50 kHz (31.25 MHz: rp.set_freq(1))
    rp.set_phase(0)
    rp.set_modulation_amplitud(100, ch='out1')         # A Out1 = 100 (as lock_mode): OUT1 +-50 counts
    rp.set_modulation_amplitud(-1, ch='out2')
    rp.set_lpf(tau_exponent=15, order=2, line='xy')    # sqX, sqY: 262 us, 2nd order
    rp.set_gain('xy', 'x32')
    rp.lock.error_sw = 'sqYo'                          # error signal = sqYo (sqXo or sqFo, depending on the phase)
    rp.set_pid('A', sw='error', sp=0, kp=-500, ki=-20, kd=0, PSR=3, ISR=8, DSR=0, SAT=13)
    rp.pid_reset('A')
    rp.lock.out1_sw  = 'ctrl_A'                        # OUT1 = PID A + ramp A (+ modulation)
else:
    print('WARNING: with the modulation off or kp = ki = 0 the lock below does not hold anything '
          '(the level trigger needs the error signal)')

# configuration: time trigger 16.58 ms after the scan floor, PID A on (ramp off) while locked. The time must be
# shorter than half the period of the ramp (Ramp cell: ~64 ms); with dummy_simulator the peak is at ~16.3 ms.
# NOTE (v2.0.3, as lock_in+pid_harmonic v2.3.23): time=16.58e-3 and timeout=10 are for the 64 ms ramp of the lock tests
# (peak 16.58 ms after the scan floor). For another ramp use the time of the peak after the floor (e.g. ~7.6 s with a
# 30 s ramp, see "Choose from graph") and a timeout longer than the time to the next floor + that time (> 38 s with 30 s).
rp.lock_config(trig='time', time=16.58e-3, final=('pidA',))
st = rp.lock_launch(timeout=10)      # Trigger Lock and wait for LOCKED
print(st)                            # {'armed': False, 'locked': True, 'pidA': True, ...}

rp.lock_release()                    # back to the manual enables (scan)

# level trigger: error crossing 0.1 V upwards
rp.lock_config(trig='level', level_V=0.1, signal='error', rise=True, final=('pidA',))
rp.lock_launch()
rp.wait_locked(timeout=10)
rp.lock_release()

# lock now
rp.lock_now()
print(rp.lock_status())
rp.lock_release()


#%% Get all the registers of Lock module in FPGA ##############################

all_lock_regs = rp.lock.get()



#%% Interpretation of integers registers ######################################

for reg in 'oscA_sw oscB_sw'.split():
    value = rp.lock.get(reg)
    print(f'{reg} = {value}')

for reg in 'oscA_sw oscB_sw'.split():
    value = rp.lock.get(reg)
    label = reg_labels[reg][value]
    print(f'{reg} = "{label}"')







#%% Load configuration from a web saved json ##################################

fn = 'RP.json'


if os.path.isfile(fn):
    with open(fn,'r') as rpcur_fp:
        rpcur_config = json.load(rpcur_fp)

    config_lock = { k[5:]:v for k,v in rpcur_config['data'].items() if k[:5]=='lock_' }

    # Load only RW registers
    for key, val in config_lock.items():
        if key in rp.lock._registers.keys() and not rp.lock._registers[key][2]:
            print(key)
            rp.lock.set(key,val)




#%% Streaming example #########################################################

def IPtoReg(txt):
    vec = txt.strip().split('.')
    if not len(vec) == 4:
        raise ValueError('this is not an IPv4')

    return sum([ int(v)<<(i*8) for i,v in enumerate(vec) ])

def REgtoIP(val):
    return f'{val&255}.{(val>>8)&255}.{(val>>8*2)&255}.{(val>>8*3)&255}'


rp.lock.oscA_sw  = 'sq_ref'
rp.lock.oscB_sw  = 'sqXo'



rp.lock.stream_rate = 1024

rp.lock.stream_port = 6000

REgtoIP( rp.lock.stream_ip )


rp.streaming_prepare()


rp.streaming_start()

rp.streaming_stop()
