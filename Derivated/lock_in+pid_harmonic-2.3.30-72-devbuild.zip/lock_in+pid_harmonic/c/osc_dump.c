/*
 * osc_dump: captures the scope of lock_in+pid_harmonic Count times and writes the traces to stdout
 * (binary, or text with --verbose). Used by c/osc_to_tcp.py (forwards stdout to a TCP host:port).
 *
 * Origin: osc_dump V0.1 (0.9x ecosystem). Adapted (trial, not versioned yet) to the 2.0 FPGA of the App
 * (rp_scope_cfg.v / rp_bram_sm.v / rp_trig_src.v of fpga/rtl/rtl/classic, lock.v of fpga/prj/v0.94):
 *
 *  - Trigger lock: every trigger locks the trigger logic (TrgSrc bit 5 reads 1) until 1 is written to
 *    TrgUnlock (0x94). It is written before TrgSrc on every capture (as src/fpga.c osc_fpga_set_trigger()).
 *    In the 0.9x scope 0x94 is unmapped (the write is ignored).
 *  - End of the capture: in 2.0 the arm bit (conf bit 0) always reads 0, so the old wait
 *    "while (conf & 1)" did not wait at all. The end is conf bit 4 (adc_dly_end, 2.0) or, in 0.9x,
 *    TrgSrc back to 0 with conf bit 2 clear (same test as src/fpga.c osc_fpga_triggered()).
 *  - Pre-trigger: before the trigger source is written it waits until the samples written since the arm
 *    (0x2C, adc_we_cnt) cover the part of the read window older than the trigger (NumDat - TrgDelay), so the
 *    whole window belongs to this capture.
 *  - Samples: the 2.0 FPGA (SCOPE_DW = 16) returns them sign-extended to 16 bits, 0.9x as 14 bits with zeros
 *    above. fix_sign() keeps the 14 ADC bits and sign-extends them: right in both.
 *  - Coordination with the App: the worker of the controller (src/worker.c) does not reset, arm or configure
 *    the scope while the lock register stream_cmd (0x188) is != 0. osc_dump writes OSC_DUMP_STREAM_CMD (2)
 *    there: != 0 for the worker, but bit 0 = 0, so the decimation is not replaced by stream_rate (lock.v:
 *    osc_ctrl_w[2] = stream_cmd[0] overrides Dec in rp_scope_com.v). At the end (also on SIGINT, SIGTERM,
 *    SIGHUP, SIGPIPE and errors) the scope is reset, Dec and TrgDelay are restored and stream_cmd goes back
 *    to 0: the worker arms its scope again. If stream_cmd is changed by someone else meanwhile (a lock POST
 *    of the page writes its parameter lock_stream_cmd = 0, rp_app_exit writes 0) osc_dump stops at once
 *    (with 0: Dec and TrgDelay restored, no reset).
 *    It refuses to start if stream_cmd != 0 (streaming or another osc_dump) or if c/streaming is waiting
 *    (it would start a streaming as soon as stream_cmd != 0).
 *  - Only 32-bit volatile accesses to the PL (no memcpy / burst reads on 0x4xxxxxxx: they hung the board).
 *
 * Output format (unchanged):
 *   binary, per capture: cnt_clk (u32), cnt_clk2 (u32), NumDat words  (chB << 16) | (chA & 0xFFFF)
 *                        (int16 each, chA = scope channel 1 = lock oscA_sw, at 0x10000), end marker 0xffffffff
 *   --verbose: "timestamp: <50-bit count of 8 ns clocks>" and "<ptr> <chA> <chB>" lines
 * The timestamp is the lock counter (read_ctrl bit 1 = run) read after the capture is complete.
 *
 * VERSION V0.1 (original notes)
 * Tiene invertidos los canales
 * y usa NumDat en vez de StartWpt y StopWpt
 * VERSION V0 con opciones de línea de comando para setear parámetros
 *  y opción verbose para mostrar parámetros y datos en formato texto
 *  en lugar de binario.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdint.h>
#include <inttypes.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <signal.h>
#include <dirent.h>


// Valores por defecto
#define DEFAULT_TrgSrc 5
#define DEFAULT_TrgDelay 16364
#define DEFAULT_Dec -1
#define DEFAULT_NumDat 16383
#define DEFAULT_Count 1


// Valores para FPGA
#define OSC_FPGA_BASE_ADDR 0x40100000
#define OSC_FPGA_BASE_SIZE 0x30000
#define OSC_FPGA_SIG_LEN   16384
#define OSC_FPGA_CH_A_OFFSET 0x10000
#define OSC_FPGA_CH_B_OFFSET 0x20000

#define LOCK_FPGA_BASE_ADDR 0x40600000
#define LOCK_FPGA_MAP_SIZE  0x1000      // only the first registers are used (up to stream_cmd, 0x188)


// Indices Lock (offset / 4)
#define CNT_CLK 64
#define CNT_CLK2 65
#define READ_CTRL 66
#define STREAM_CMD 98                   // 0x188

// stream_cmd value of osc_dump: != 0 (the App worker leaves the scope), bit 0 = 0 (no decimation override)
#define OSC_DUMP_STREAM_CMD 2

// Indices Oscilloscope (offset / 4)
#define CONF 0
#define TRGSRC 1
#define CHATH 2
#define CHBTH 3
#define TRGDELAY 4
#define DEC 5
#define CURWPT 6
#define TRGWPT 7
#define CHAHYS 8
#define CHBHYS 9
#define AVGEN 10
#define PRETRGCNT 11                    // 0x2C: samples written since the arm, before the trigger
#define TRGUNLOCK 37                    // 0x94 (2.0): write 1 to unlock the trigger

#define CONF_ARM        0x1
#define CONF_RST        0x2
#define CONF_TRIG_ST    0x4             // trigger received (2.0) / post-trigger delay running (0.9x)
#define CONF_ACQ_DONE   0x10            // 2.0: post-trigger delay over
#define TRGSRC_RD_MASK  0x1f


// Variables globales para almacenar los parámetros
int TrgSrc = DEFAULT_TrgSrc;
int TrgDelay = DEFAULT_TrgDelay;
int Dec = DEFAULT_Dec;
int NumDat = DEFAULT_NumDat;
unsigned long Count = DEFAULT_Count;

int Verbose = 0;
int ResetCounter = 0;

// Bandera para indicar qué parámetros fueron establecidos
bool TrgSrc_set = false;
bool TrgDelay_set = false;
bool Dec_set = false;
bool NumDat_set = false;
bool Count_set = false;

static volatile sig_atomic_t g_stop_sig = 0;

static void on_signal(int sig)
{
    g_stop_sig = sig;
}


// Función para convertir string a entero con validación
int parse_int_param(const char *param_name, const char *value_str, int *result) {
    char *endptr;
    errno = 0;
    long value = strtol(value_str, &endptr, 10);

    if (*endptr != '\0' || endptr == value_str) {
        fprintf(stderr, "Error: '%s' no es un número entero válido para %s\n",
                value_str, param_name);
        return -1;
    }
    if (errno == ERANGE || value < -2147483647L || value > 2147483647L) {
        fprintf(stderr, "Error: '%s' está fuera del rango para %s\n",
                value_str, param_name);
        return -1;
    }
    *result = (int)value;
    return 0;
}

int parse_ulong_param(const char *param_name, const char *value_str, unsigned long *result) {
    char *endptr;
    errno = 0;
    long long value = strtoll(value_str, &endptr, 10);

    if (*endptr != '\0' || endptr == value_str) {
        fprintf(stderr, "Error: '%s' no es un número entero válido para %s\n",
                value_str, param_name);
        return -1;
    }
    if (errno == ERANGE || value < 0 || value > 4294967295LL) {
        fprintf(stderr, "Error: '%s' está fuera del rango para %s\n",
                value_str, param_name);
        return -1;
    }
    *result = (unsigned long)value;
    return 0;
}

/* Two's complement of a scope sample: keeps the 14 ADC bits and sign-extends them.
 * 2.0 FPGA: the sample comes sign-extended to 16 bits; 0.9x: 14 bits, zeros above. */
static inline int32_t fix_sign(uint32_t value){
    value &= 0x3fff ;
    return (value & 0x2000) ? (int32_t)value - 0x4000 : (int32_t)value ;
}


// Función para procesar un parámetro
int process_parameter(const char *arg) {
    const char *equal_sign = strchr(arg, '=');

    if (equal_sign == NULL) {
        fprintf(stderr, "Error: Formato incorrecto en '%s'. Use --parametro=valor\n", arg);
        return -1;
    }

    size_t name_len = equal_sign - arg;
    char param_name[32];
    char value_str[32];

    if (name_len >= sizeof(param_name) || name_len < 3) {
        fprintf(stderr, "Error: Nombre de parámetro inválido en '%s'\n", arg);
        return -1;
    }

    strncpy(param_name, arg + 2, name_len - 2); // +2 para saltar "--"
    param_name[name_len - 2] = '\0';

    strncpy(value_str, equal_sign + 1, sizeof(value_str) - 1);
    value_str[sizeof(value_str) - 1] = '\0';

    if (strcmp(param_name, "TrgSrc") == 0) {
        TrgSrc_set = true;
        return parse_int_param("TrgSrc", value_str, &TrgSrc);
    }
    else if (strcmp(param_name, "TrgDelay") == 0) {
        TrgDelay_set = true;
        return parse_int_param("TrgDelay", value_str, &TrgDelay);
    }
    else if (strcmp(param_name, "Dec") == 0) {
        Dec_set = true;
        return parse_int_param("Dec", value_str, &Dec);
    }
    else if (strcmp(param_name, "NumDat") == 0) {
        NumDat_set = true;
        return parse_int_param("NumDat", value_str, &NumDat);
    }
    else if (strcmp(param_name, "Count") == 0) {
        Count_set = true;
        return parse_ulong_param("Count", value_str, &Count);
    }
    else {
        fprintf(stderr, "Error: Parámetro desconocido '%s'\n", param_name);
        return -1;
    }
}

// Función para mostrar ayuda de uso
void show_usage(const char *program_name) {
    printf("Uso: %s [PARÁMETROS]\n", program_name);
    printf("Parámetros (todos opcionales, usar --parametro=valor):\n");
    printf("  --TrgSrc=NUM    : fuente de trigger, <0: no se escribe (valor por defecto: %d)\n", DEFAULT_TrgSrc);
    printf("  --TrgDelay=NUM  : muestras después del trigger, <0: la de la App (valor por defecto: %d)\n", DEFAULT_TrgDelay);
    printf("  --Dec=NUM       : decimación 1..1048575, <0: la de la App (valor por defecto: %d)\n", DEFAULT_Dec);
    printf("  --NumDat=NUM    : muestras por captura, 1..%d (valor por defecto: %d)\n", OSC_FPGA_SIG_LEN, DEFAULT_NumDat);
    printf("  --Count=NUM     : cantidad de capturas, >=1 (valor por defecto: %d)\n", DEFAULT_Count);
    printf("  --verbose       : Activar salida detallada en texto\n");
    printf("  --resetcounter  : Reinicia el contador de la RP\n");
    printf("  --help          : Mostrar esta ayuda\n");
    printf("\nEjemplos:\n");
    printf("  %s --TrgSrc=10 --NumDat=5000\n", program_name);
    printf("  %s --Dec=5 --NumDat=200\n", program_name);
    printf("  %s --help\n", program_name);
}

// Función para mostrar los valores actuales de los parámetros
void show_parameters() {
    printf("Parámetros establecidos:\n");
    printf("  TrgSrc       : %d %s\n", TrgSrc      , TrgSrc_set   ? "(establecido)" : "(valor por defecto)");
    printf("  TrgDelay     : %d %s\n", TrgDelay    , TrgDelay_set ? "(establecido)" : "(valor por defecto)");
    printf("  Dec          : %d %s\n", Dec         , Dec_set      ? "(establecido)" : "(valor por defecto)");
    printf("  NumDat       : %d %s\n", NumDat      , NumDat_set   ? "(establecido)" : "(valor por defecto)");
    printf("  Count        : %lu %s\n", Count      , Count_set    ? "(establecido)" : "(valor por defecto)");
    printf("  Verbose      : %d %s\n", Verbose     , Verbose      ? "(activo)" : "(por defecto)");
    printf("  ResetCounter : %d %s\n", ResetCounter, ResetCounter ? "(activo)" : "(por defecto)");
}


/* 1 if c/streaming or c/stream_tcp_osc_cmd (of any App) is running: c/streaming waits for stream_cmd != 0
 * to start a streaming, so osc_dump must not take the scope while it waits */
static int streaming_running(void)
{
    static const char *names[] = { "/c/streaming", "/c/stream_tcp_osc_cmd" };
    char path[64], exe[512];
    int found = 0;
    DIR *d = opendir("/proc");
    struct dirent *e;
    if (!d)
        return 0;
    while ((e = readdir(d)) != NULL && !found) {
        char *end;
        long pid = strtol(e->d_name, &end, 10);
        if (*end != '\0' || pid <= 1)
            continue;
        snprintf(path, sizeof(path), "/proc/%ld/exe", pid);
        ssize_t n = readlink(path, exe, sizeof(exe) - 1);
        if (n <= 0)
            continue;
        exe[n] = '\0';
        for (unsigned i = 0; i < sizeof(names)/sizeof(names[0]); i++) {
            size_t ln = strlen(names[i]);
            char  *p  = strstr(exe, names[i]);
            if (p && (p[ln] == '\0' || p[ln] == ' '))
                found = 1;
        }
    }
    closedir(d);
    return found;
}

/* write() of the whole buffer (stdout may be a pipe) */
static int write_all(const void *buf, size_t len)
{
    const uint8_t *p = buf;
    while (len > 0) {
        // a signal during a blocked write() that had already written part of the buffer does not return
        // EINTR but the partial count: test the flag here too (else the next write() blocks for ever if
        // the reader does not read any more)
        if (g_stop_sig)
            return -1;
        ssize_t n = write(STDOUT_FILENO, p, len);
        if (n < 0) {
            if (errno == EINTR && !g_stop_sig)
                continue;
            return -1;
        }
        p   += n;
        len -= (size_t)n;
    }
    return 0;
}


// ************************************************************************************************

// For memory reading
static const char *name_mem = "/dev/mem";

static volatile uint32_t *osc  = NULL ;
static volatile uint32_t *lock = NULL ;
static volatile uint32_t *vecA = NULL ;
static volatile uint32_t *vecB = NULL ;

static int      scope_taken = 0 ;       // stream_cmd = OSC_DUMP_STREAM_CMD written by us
static uint32_t saved_dec = 0, saved_dly = 0 ;

/* stream_cmd is still ours (else the App or a streaming took the scope back) */
static int scope_still_ours(void)
{
    return lock[STREAM_CMD] == OSC_DUMP_STREAM_CMD ;
}

/* Gives the scope back to the App: reset, Dec and TrgDelay of the App, stream_cmd = 0 */
static void release_scope(void)
{
    if (!scope_taken)
        return;
    scope_taken = 0;
    if (!scope_still_ours()) {
        uint32_t sc = lock[STREAM_CMD];
        if (sc == 0) {
            // the App took it back (lock POST of the page, rp_app_exit): its worker re-arms without rewriting
            // Dec / TrgDelay, so they are restored (no reset: the worker may have armed already)
            osc[TRGDELAY] = saved_dly ;
            osc[DEC]      = saved_dec ;
            fprintf(stderr, "osc_dump: stream_cmd = 0 written by another process: Dec/TrgDelay restored\n");
        } else {
            // a streaming owns it now: do not touch the scope
            fprintf(stderr, "osc_dump: stream_cmd changed by another process (%u): scope not restored\n",
                    (unsigned)sc);
        }
        return;
    }
    osc[CONF]     = CONF_RST ;          // also clears the trigger source (2.0) and the write pointer
    osc[TRGDELAY] = saved_dly ;
    osc[DEC]      = saved_dec ;
    lock[STREAM_CMD] = 0 ;              // the App worker arms its scope again
}


int main(int argc, char *argv[]) {
    int ret = EXIT_FAILURE;
    int fd = -1;
    void *osc_ptr  = MAP_FAILED;
    void *lock_ptr = MAP_FAILED;
    uint32_t *buf = NULL;

    // Procesar todos los argumentos
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--help") == 0) {
            show_usage(argv[0]);
            return 0;
        }
        else if (strcmp(argv[i], "--verbose") == 0) {
            Verbose = 1;
        }
        else if (strcmp(argv[i], "--resetcounter") == 0) {
            ResetCounter = 1;
        }
        else if (strncmp(argv[i], "--", 2) == 0) {
            if (process_parameter(argv[i]) != 0) {
                return 1;
            }
        }
        else {
            fprintf(stderr, "Error: Argumento desconocido '%s'\n", argv[i]);
            fprintf(stderr, "Use --help para ver la ayuda\n");
            return 1;
        }
    }

    if (NumDat < 1 || NumDat > OSC_FPGA_SIG_LEN) {
        fprintf(stderr, "Error: NumDat debe estar entre 1 y %d\n", OSC_FPGA_SIG_LEN);
        return 1;
    }
    if (Count < 1) {
        fprintf(stderr, "Error: Count debe ser >= 1\n");
        return 1;
    }
    if (Dec == 0 || Dec > 1048575) {
        fprintf(stderr, "Error: Dec debe estar entre 1 y 1048575 (o <0: la de la App)\n");
        return 1;
    }
    if (TrgSrc > 31) {
        fprintf(stderr, "Error: TrgSrc debe estar entre 0 y 31 (o <0: no se escribe)\n");
        return 1;
    }
    if (TrgSrc_set && TrgSrc <= 0)
        fprintf(stderr, "osc_dump: aviso: sin fuente de trigger (TrgSrc=%d) la captura espera hasta Ctrl+C\n", TrgSrc);

    buf = malloc((size_t)NumDat * sizeof(uint32_t));
    if (!buf) {
        fprintf(stderr, "[-] malloc failed\n");
        return 1;
    }

    // SIGINT/SIGTERM/SIGHUP/SIGPIPE: end the current wait or write, release the scope and leave
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = on_signal;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;                    // no SA_RESTART: write() returns EINTR
    sigaction(SIGINT , &sa, NULL);
    sigaction(SIGTERM, &sa, NULL);
    sigaction(SIGHUP , &sa, NULL);
    sigaction(SIGPIPE, &sa, NULL);

    if((fd = open(name_mem, O_RDWR | O_SYNC)) < 0) {
        perror("[-] Error trying to open /dev/mem");
        goto out;
    }

    osc_ptr = mmap(NULL, OSC_FPGA_BASE_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd , OSC_FPGA_BASE_ADDR);
    if(osc_ptr == MAP_FAILED) {
        fprintf(stderr, "[-] osc mmap() failed: %d\n", errno);
        goto out;
    }
    lock_ptr = mmap(NULL, LOCK_FPGA_MAP_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd , LOCK_FPGA_BASE_ADDR);
    if(lock_ptr == MAP_FAILED) {
        fprintf(stderr, "[-] lock mmap() failed: %d\n", errno);
        goto out;
    }
    osc  = (volatile uint32_t *)osc_ptr ;
    lock = (volatile uint32_t *)lock_ptr ;
    vecA = (volatile uint32_t *)((uint8_t *)osc_ptr + OSC_FPGA_CH_A_OFFSET) ;  // channel A (lock oscA_sw)
    vecB = (volatile uint32_t *)((uint8_t *)osc_ptr + OSC_FPGA_CH_B_OFFSET) ;  // channel B (lock oscB_sw)

    // ---- take the scope from the App ----
    {
        uint32_t sc = lock[STREAM_CMD];
        if (sc != 0) {
            fprintf(stderr, "osc_dump: el scope está ocupado (stream_cmd = %u: streaming u otro osc_dump)\n", (unsigned)sc);
            goto out;
        }
        if (streaming_running()) {
            fprintf(stderr, "osc_dump: c/streaming está corriendo (Prepare Streaming): detenerlo antes\n");
            goto out;
        }
    }
    saved_dec = osc[DEC];
    saved_dly = osc[TRGDELAY];
    lock[STREAM_CMD] = OSC_DUMP_STREAM_CMD ;
    scope_taken = 1;
    usleep(50000);                      // the worker checks stream_cmd at least every 10 ms

    if (Verbose) show_parameters();

    // Reset oscilloscope
    osc[CONF] = CONF_RST;
    usleep(1000);

    if (Dec>=0) osc[DEC] = (uint32_t)Dec ;
    if (TrgDelay>=0) osc[TRGDELAY] = (uint32_t)TrgDelay ;

    // pre-trigger samples needed so that the whole read window belongs to this capture
    uint32_t dly = osc[TRGDELAY];
    uint32_t pre_need = 0;
    if ((uint32_t)NumDat > dly)
        pre_need = (uint32_t)NumDat - dly;
    if (pre_need > OSC_FPGA_SIG_LEN)
        pre_need = OSC_FPGA_SIG_LEN;

    if (ResetCounter)
        lock[READ_CTRL] = 0 ;
    lock[READ_CTRL] = 2 ;               // run the clock counter (timestamps)

    usleep(10000);
    for (unsigned long count=0 ; count<Count ; count++ ) {
        int k = 0;

        // Arm: the FPGA writes from now on
        osc[CONF] = CONF_ARM;

        // pre-trigger history
        while (osc[PRETRGCNT] < pre_need) {
            if (g_stop_sig) goto stopped;
            if ((++k & 63) == 0 && !scope_still_ours()) goto lost;
            usleep(100);
        }

        // unlock the trigger (2.0), then its source
        osc[TRGUNLOCK] = 1;
        if (TrgSrc >= 0) osc[TRGSRC] = (uint32_t)TrgSrc ;
        usleep(100);                    // the source is in the FPGA before the first test below

        // wait for the end of the capture (trigger + TrgDelay samples)
        k = 0;
        while (1) {
            uint32_t src  = osc[TRGSRC];
            uint32_t conf = osc[CONF];
            if (conf & CONF_ACQ_DONE)
                break;                                  // 2.0
            if (((src & TRGSRC_RD_MASK) == 0) && !(conf & CONF_TRIG_ST) && TrgSrc > 0)
                break;                                  // 0.9x
            if (g_stop_sig) goto stopped;
            if ((++k & 127) == 0 && !scope_still_ours()) goto lost;
            usleep(50);
        }

        uint32_t read_ptr_start = osc[TRGWPT] & 0x3fff;

        lock[READ_CTRL] = 3 ;           // freeze the copies, read the counter
        uint32_t cnt_clk  = lock[CNT_CLK];
        uint32_t cnt_clk2 = lock[CNT_CLK2];
        lock[READ_CTRL] = 2 ;

        // read the window: one 32-bit access per sample and channel
        for (int jj=0 ; jj<NumDat ; jj++ ) {
            uint32_t rp = (read_ptr_start + (uint32_t)jj) & 0x3fff ;
            int32_t a = fix_sign(vecA[rp]);
            int32_t b = fix_sign(vecB[rp]);
            buf[jj] = ((uint32_t)b << 16) | ((uint32_t)a & 0x0000FFFF) ;
        }
        if (!scope_still_ours()) goto lost;     // reconfigured under the read: drop it

        if (Verbose){
            printf("timestamp: %" PRIu64 "\n", ((uint64_t)cnt_clk2 << 32) | cnt_clk);
            for (int jj=0 ; jj<NumDat ; jj++ ) {
                printf("%5d %5d %5d\n", (int)((read_ptr_start + (uint32_t)jj) & 0x3fff),
                       (int)(int16_t)(buf[jj] & 0xffff), (int)(int16_t)(buf[jj] >> 16));
            }
            printf("\n");
            if (fflush(stdout) != 0 || ferror(stdout)) {
                if (g_stop_sig) goto stopped;
                fprintf(stderr, "osc_dump: error de escritura en stdout\n");
                goto out;
            }
        }
        else {
            uint32_t hdr[2] = { cnt_clk, cnt_clk2 };
            uint32_t end_marker = 0xffffffff;
            if (write_all(hdr, sizeof(hdr)) || write_all(buf, (size_t)NumDat * sizeof(uint32_t)) ||
                write_all(&end_marker, sizeof(end_marker))) {
                if (g_stop_sig) goto stopped;
                fprintf(stderr, "osc_dump: error de escritura en stdout: %s\n", strerror(errno));
                goto out;
            }
        }
        if (g_stop_sig) goto stopped;
    }
    ret = EXIT_SUCCESS;
    goto out;

stopped:
    fprintf(stderr, "osc_dump: señal %d, terminando\n", (int)g_stop_sig);
    ret = 128 + (int)g_stop_sig;
    goto out;

lost:
    fprintf(stderr, "osc_dump: stream_cmd cambiado por otro proceso (%u): captura abortada\n",
            (unsigned)lock[STREAM_CMD]);
    ret = EXIT_FAILURE;

out:
    if (osc && lock)
        release_scope();
    if (lock_ptr != MAP_FAILED) munmap(lock_ptr, LOCK_FPGA_MAP_SIZE);
    if (osc_ptr  != MAP_FAILED) munmap(osc_ptr , OSC_FPGA_BASE_SIZE);
    if (fd >= 0) close(fd);
    free(buf);
    return ret;
}
