#!/bin/bash
# lock_in+pid_harmonic (osc_dump trial, not versioned yet): starts c/osc_to_tcp.py detached from nginx.
# Called by the /lock_in+pid_harmonic/run_dump location of nginx.conf, which already validated the
# arguments. They are checked again here, so that no other string reaches osc_to_tcp.py:
#
#     dump_start.sh IP [TrgSrc=N] [TrgDelay=N] [Dec=N] [NumDat=N] [Count=N] [port=N] [ResetCounter=1]
#
# Exit codes: 0 started, 1 bad arguments, 2 busy (a dump or a streaming is already running).
D=/opt/redpitaya/www/apps/lock_in+pid_harmonic/c
LOG=/tmp/lock_in+pid_harmonic_dump.log

is_int() {   # is_int VALUE MIN MAX
    case "$1" in
        ''|*[!0-9-]*|?*-*|-) return 1 ;;
    esac
    [ ${#1} -le 10 ] || return 1
    [ "$1" -ge "$2" ] 2>/dev/null && [ "$1" -le "$3" ] 2>/dev/null
}

IP="$1"; shift
case "$IP" in
    ''|*[!0-9.]*) echo "bad ip"; exit 1 ;;
esac
IFS=. read -r o1 o2 o3 o4 o5 <<< "$IP"
for o in "$o1" "$o2" "$o3" "$o4"; do
    is_int "$o" 0 255 || { echo "bad ip"; exit 1; }
done
[ -z "$o5" ] || { echo "bad ip"; exit 1; }

PY_ARGS=()
for a in "$@"; do
    k="${a%%=*}"; v="${a#*=}"
    case "$k" in
        TrgSrc)       is_int "$v" 1 31              && PY_ARGS+=("--TrgSrc=$v")   || { echo "bad $k"; exit 1; } ;;
        TrgDelay)     is_int "$v" -1 100000000      && PY_ARGS+=("--TrgDelay=$v") || { echo "bad $k"; exit 1; } ;;
        Dec)          { is_int "$v" 1 1048575 || [ "$v" = "-1" ]; } && PY_ARGS+=("--Dec=$v") || { echo "bad $k"; exit 1; } ;;
        NumDat)       is_int "$v" 1 16384           && PY_ARGS+=("--NumDat=$v")   || { echo "bad $k"; exit 1; } ;;
        Count)        is_int "$v" 1 1000000         && PY_ARGS+=("--Count=$v")    || { echo "bad $k"; exit 1; } ;;
        port)         is_int "$v" 1 65535           && PY_ARGS+=("-p" "$v")       || { echo "bad $k"; exit 1; } ;;
        ResetCounter) [ "$v" = "1" ]                && PY_ARGS+=("--ResetCounter") || { echo "bad $k"; exit 1; } ;;
        *) echo "bad key"; exit 1 ;;
    esac
done

# Only one dump at a time, and not while streaming (both use the scope).
if pidof $D/osc_dump $D/streaming $D/stream_tcp_osc_cmd >/dev/null 2>&1 \
   || pgrep -f "$D/osc_to_tcp.py" >/dev/null 2>&1; then
    echo "BUSY"
    exit 2
fi

# Do not pass the fds of the nginx worker (client and listening sockets, logs) to the dump
# (as c/streaming does): they would stay open while it runs.
for fd in $(ls /proc/$$/fd); do
    [ "$fd" -gt 2 ] && eval "exec $fd>&-" 2>/dev/null
done

if command -v setsid >/dev/null 2>&1; then
    setsid /usr/bin/python3 $D/osc_to_tcp.py "$IP" "${PY_ARGS[@]}" > $LOG 2>&1 < /dev/null &
else
    nohup  /usr/bin/python3 $D/osc_to_tcp.py "$IP" "${PY_ARGS[@]}" > $LOG 2>&1 < /dev/null &
fi
echo "STARTED"
exit 0
