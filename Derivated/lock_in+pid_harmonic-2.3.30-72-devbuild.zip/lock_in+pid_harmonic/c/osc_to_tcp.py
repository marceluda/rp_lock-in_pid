#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Runs c/osc_dump on the Red Pitaya and forwards its stdout (binary traces) to a TCP host:port.

    osc_to_tcp.py HOST [-p PORT] [--TrgSrc N] [--TrgDelay N] [--Dec N] [--NumDat N] [--Count N] [--ResetCounter]

Only the options given are passed to osc_dump (the others take the defaults of osc_dump).
Format of the stream: see c/osc_dump.c (per capture: cnt_clk, cnt_clk2, NumDat words
(chB << 16) | (chA & 0xFFFF), end marker 0xffffffff; little endian, 32-bit words).

Trial (not versioned yet). Runs with the python3 of the board (Python 3.10, standard library only).
Messages go to stderr. SIGINT/SIGTERM/SIGHUP or a closed connection stop osc_dump with SIGTERM:
osc_dump gives the scope back to the App before it ends.
"""

import argparse
import os
import signal
import socket
import subprocess
import sys

HERE     = os.path.dirname(os.path.abspath(__file__))
OSC_DUMP = os.path.join(HERE, 'osc_dump')


class _Stop(Exception):
    pass


def _on_signal(signum, frame):
    raise _Stop(signum)


def log(msg):
    print(msg, file=sys.stderr, flush=True)


def main():
    parser = argparse.ArgumentParser(
        description='Redirigir osc_dump a TCP',
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    parser.add_argument('host', type=str, help='Host destino (obligatorio)')
    parser.add_argument('-p', '--port', type=int, default=8080, help='Puerto destino')
    # SUPPRESS: only the given options are passed to osc_dump. The defaults in the help are the ones of osc_dump.
    parser.add_argument('--TrgSrc'  , type=int, default=argparse.SUPPRESS, help='fuente de trigger (osc_dump: 5)')
    parser.add_argument('--TrgDelay', type=int, default=argparse.SUPPRESS, help='muestras tras el trigger (osc_dump: 16364)')
    parser.add_argument('--Dec'     , type=int, default=argparse.SUPPRESS, help='decimación (osc_dump: -1 = la de la App)')
    parser.add_argument('--NumDat'  , type=int, default=argparse.SUPPRESS, help='muestras por captura (osc_dump: 16383)')
    parser.add_argument('--Count'   , type=int, default=argparse.SUPPRESS, help='cantidad de capturas (osc_dump: 1)')
    parser.add_argument('--ResetCounter', action='store_true', default=False, help='reinicia el contador de la RP')
    args = parser.parse_args()

    if not (1 <= args.port <= 65535):
        parser.error('port fuera de rango (1..65535)')

    command = [OSC_DUMP]
    for name in ('TrgSrc', 'TrgDelay', 'Dec', 'NumDat', 'Count'):
        if hasattr(args, name):
            command.append('--{0:s}={1:d}'.format(name, getattr(args, name)))
    if args.ResetCounter:
        command.append('--resetcounter')

    log('osc_to_tcp: ' + ' '.join(command) + ' -> {}:{}'.format(args.host, args.port))

    for s in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
        signal.signal(s, _on_signal)

    sock = None
    process = None
    rc = 1
    try:
        # connect first: if the receiver is not there the scope of the App is not taken
        sock = socket.create_connection((args.host, args.port), timeout=10)
        sock.settimeout(None)
        log('osc_to_tcp: conectado a {}:{}'.format(args.host, args.port))

        process = subprocess.Popen(command, stdout=subprocess.PIPE, bufsize=0, cwd=HERE)
        fd = process.stdout.fileno()
        nbytes = 0
        while True:
            data = os.read(fd, 65536)
            if not data:
                break
            sock.sendall(data)
            nbytes += len(data)
        rc = process.wait()
        log('osc_to_tcp: osc_dump terminó (código {}), {} bytes enviados'.format(rc, nbytes))
    except _Stop as e:
        log('osc_to_tcp: señal {}, terminando'.format(e.args[0]))
        rc = 128 + int(e.args[0])
    except OSError as e:
        log('osc_to_tcp: error: {}'.format(e))
        rc = 1
    finally:
        # ignore further signals while cleaning up
        for s in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
            signal.signal(s, signal.SIG_IGN)
        if process is not None and process.poll() is None:
            # close the pipe first: a write() of osc_dump blocked on it ends with EPIPE (SIGPIPE)
            process.stdout.close()
            process.terminate()             # osc_dump releases the scope on SIGTERM / SIGPIPE
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
        if sock is not None:
            sock.close()
    return rc


if __name__ == '__main__':
    sys.exit(main())
